

--[[

find
lower ~~ DONE
format
rep ~~
gsub
len ~~ DONE
gmatch
dump
match
reverse ~~ DONE
byte
char
upper
gfind
sub ~~ DONE




]]