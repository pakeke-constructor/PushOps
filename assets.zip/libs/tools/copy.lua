
return function(t)
    local ret = {}
    for i=1,#t do
        ret[i] = t[i]
    end
    return ret
end
