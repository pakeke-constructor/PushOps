

--[[

Boss wizard that has a gold hat, and is extremely hard to kill.


]]

return function()
    error("bosswizard not done yet")
end

