


local Atlas = require("assets.atlas")
local Quads = Atlas.Quads
local EH = EH
local BT = EH.BT
local ccall = Cyan.call


return function(x, y)

    local e = Cyan.Entity()
    EH.PV(e,x,y)

    

end



