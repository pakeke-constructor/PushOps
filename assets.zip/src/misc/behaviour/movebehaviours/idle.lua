
local IDLE = {}
function IDLE:init()
end
function IDLE:update(dt)
end
return IDLE


