



local font = love.graphics.newImageFont("assets/main_font.png", ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789><:$,.!@()??????')
love.graphics.setFont(font)
return font


