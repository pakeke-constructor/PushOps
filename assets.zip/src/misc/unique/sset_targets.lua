
--[[

A set of weak arrays that contain entities of certain target groups.
    NOT ALL TARGET_IDs are used!!! This is done to save space

]]

return {
    interact = Tools.set()
}

