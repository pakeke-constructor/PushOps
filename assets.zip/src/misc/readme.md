
# MISC

This is a folder that holds all the lua files that aren't an entity or system.

Thats kinda vague, so here is a list of the stuff it has:
- World gen config
- Sound config
- Animation classes
- particle classes
- behaviour tree task bases
- camera instantiation
- spatial partition instantiation
- gamestate and shaders

