
# playables

this folder contains a bunch of classes for playable
characters.

Everything inherits from `base`.


When changing to a skin, 
`:construct(player)`
 is called

when changing *away* from a skin,
`:destruct(player)`
is called.

