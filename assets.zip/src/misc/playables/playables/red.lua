
return {
    prefix = "red_player_"
}

