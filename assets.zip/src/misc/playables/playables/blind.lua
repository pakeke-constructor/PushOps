
return {
    prefix = "blind_player_"
}

