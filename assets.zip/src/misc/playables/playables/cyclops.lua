
return {
    prefix = "cyclops_player_"
}


