
--[[

pull and push strength increased by 20%

]]


return {
    load = function(player)
        player.strength = player.strength * 1.2
    end
}


