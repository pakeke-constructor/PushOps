
return {
    -- Self explanatory
}

--[[
TODO:

    All you need is less
        <Note: this upgrade does nothing.
        It should always be available:
        it serves as a way to opt out of taking
        an upgrade.>
        <
        If player kills a boss with no upgrades,
        a new character should be unlocked
        >
]]