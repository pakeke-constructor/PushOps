
PATH = "D:\\PROGRAMMING\\LUA\\SCRIPTS\\push_game"

'''
TODO

make an exe generator


cd D:\PROGRAMMING\LUA\SCRIPTS\PUSH_GAME_PACKAGER
copy /b D:\PROGRAMMING\LOVE\love.exe+D:\PROGRAMMING\LUA\SCRIPTS\PUSH_GAME_PACKAGER\push_game.love pushOPS.exe 

'''


