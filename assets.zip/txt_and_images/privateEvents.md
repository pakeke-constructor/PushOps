
A list of private callbacks.


# _setPos(e, x, y)
Moves an entity according to `x` and `y` in all the required
spatial partitions. 
This needs to be private because order needs to be totally conserved.
See `MoveSys:setPos` if you want more insight




